package com.example.williamrodriguez.myapplication;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.sqlite2.Lib.ConectarSqLite;
import com.example.sqlite2.Lib.EstructuraTabla.ColumnaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TablaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TipoDatoSqLite;
import com.example.sqlite2.Lib.ReadTable.DatosColumna;
import com.example.sqlite2.Lib.ReadTable.DatosTabla;
import com.example.sqlite2.Lib.ReadTable.Fila;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TablaCrear tabla = new TablaCrear();
        tabla.setNombreTabla("WILI");
        List<ColumnaCrear> columnasDtos = new ArrayList<>();
        columnasDtos.add(new ColumnaCrear("nombre", TipoDatoSqLite.DatoString));
        columnasDtos.add(new ColumnaCrear("documento", TipoDatoSqLite.DatoEntero));
        columnasDtos.add(new ColumnaCrear("habilitado", TipoDatoSqLite.DatoBoolean));
        tabla.setColumnasDtos(columnasDtos);

        ConectarSqLite conectarSqLite = new ConectarSqLite(getApplicationContext(), tabla);

        List<DatosColumna> datosColumnas = conectarSqLite.plantillaUsoDatos();
        datosColumnas.get(0).setDatoColumna("William");
        datosColumnas.get(1).setDatoColumna(Integer.toString(123456));
        datosColumnas.get(2).setDatoColumna(Boolean.toString(false));
        int aLong = conectarSqLite.InsertarDatos(datosColumnas);



        List<DatosColumna> newdatosColumnas = conectarSqLite.plantillaUsoDatos();
        newdatosColumnas.get(0).setDatoColumna("Steve");
        int i = conectarSqLite.ActualizarDatos(newdatosColumnas, 3);


        DatosTabla datos = conectarSqLite.LeerTabla();
        for (int indiceFilas = 0; indiceFilas < datos.getTablaCompleta().size(); indiceFilas++) {
            Fila fila = datos.getTablaCompleta().get(indiceFilas);
            for (int indiceColumna = 0; indiceColumna < fila.getFila().size(); indiceColumna++) {
                DatosColumna columnas = fila.getFila().get(indiceColumna);
                Log.e(columnas.getNombreColumna(), columnas.getDatoColumna());
            }
        }
    }
}
