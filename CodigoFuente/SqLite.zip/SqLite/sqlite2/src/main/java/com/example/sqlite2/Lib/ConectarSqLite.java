package com.example.sqlite2.Lib;

import android.content.ContentValues;
import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;

import com.example.sqlite2.Lib.EstructuraTabla.ColumnaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TablaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TipoDatoSqLite;
import com.example.sqlite2.Lib.ReadTable.DatosColumna;
import com.example.sqlite2.Lib.ReadTable.DatosTabla;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class ConectarSqLite {

    private Model model;
    private TablaCrear tablaDto;


    public ConectarSqLite(Context context, TablaCrear tablaDto){
        model = new Model(context, tablaDto);
        this.tablaDto = tablaDto;
    }

    public DatosTabla LeerTabla(){
        return model.LeerTabla();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public int InsertarDatos(List<DatosColumna> tablaLlena){
        if(model.cantidadDatosInsertar() != tablaLlena.size()){
            return -1;
            //Log.e("SQLite", "Datos incompletos para ser guardados");
        }else{
            ContentValues values = ListDtoConvertContenVelues(tablaLlena);
            if(values.size()==tablaDto.getColumnasDtos().size()){
                return model.InsertarDatos(values).intValue();
            }else{
                return -2;
            }
        }
    }

    public int ActualizarDatos(List<DatosColumna> tablaLlena, int idFilaActualizar){
        if(model.cantidadDatosInsertar() != tablaLlena.size()){
            return -1;
            //Log.e("SQLite", "Datos incompletos para ser guardados");
        }else{
            ContentValues values = ListDtoConvertContenVelues(tablaLlena);
            if(values.size()>0){
                return model.ActualizarDatos(values, Integer.toString(idFilaActualizar));
            }

            /*if(values.size()==tablaDto.getColumnasDtos().size()){
                return model.ActualizarDatos(values, Integer.toString(idFilaActualizar));
            }else{
                return -2;
            }*/
            return -2;
        }
    }

    private ContentValues ListDtoConvertContenVelues(List<DatosColumna> tablaLlena){
        List<ColumnaCrear> columnasDtos2 = tablaDto.getColumnasDtos();
        ContentValues values = new ContentValues();
        if(columnasDtos2.size()==tablaLlena.size()){
            for (Iterator<DatosColumna> iterator = tablaLlena.iterator(); iterator.hasNext();) {
                DatosColumna next = iterator.next();
                //Log.e(next.getNombreColumna(), next.getDatoColumna());
                if(next.getDatoColumna() != null){
                    for (int i = 0; i < columnasDtos2.size(); i++) {
                        ColumnaCrear next2 = columnasDtos2.get(i);
                        if(next.getNombreColumna().equals(next2.getNombreColumna())){
                            if(!next.getDatoColumna().equals("")){
                                //Log.e("ColumnaEncontrada",next2.getTipoDato());
                                switch (next2.getTipoDato()){
                                    case TipoDatoSqLite.DatoBoolean:{
                                        values.put(next.getNombreColumna(), Boolean.parseBoolean(next.getDatoColumna()));
                                    }
                                    break;
                                    case TipoDatoSqLite.DatoEntero:{
                                        values.put(next.getNombreColumna(), Integer.parseInt(next.getDatoColumna()));
                                    }
                                    break;
                                    case TipoDatoSqLite.DatoString:{
                                        values.put(next.getNombreColumna(), next.getDatoColumna());
                                    }
                                    break;
                                }
                            }else{
                                //Log.e(next2.getTipoDato(),next.getDatoColumna());
                            }
                            break;
                        }
                    }
                }
            }
        }

        return  values;
    }

    public List<DatosColumna> plantillaUsoDatos(){
        List<DatosColumna> datosColumnas = new ArrayList<>();
        for (DatosColumna datosColumna : model.getPlantillaManipulacionDatos()){
            DatosColumna copy = deepCopy(datosColumna);
            datosColumnas.add(copy);
        }
        return datosColumnas;
    }

    private DatosColumna deepCopy(DatosColumna input){
        DatosColumna copy = new DatosColumna();
        copy.setDatoColumna(input.getDatoColumna());
        copy.setNombreColumna(input.getNombreColumna());
        return copy;
    }

}
