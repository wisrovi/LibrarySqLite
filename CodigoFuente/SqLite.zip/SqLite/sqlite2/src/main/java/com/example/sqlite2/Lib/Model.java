package com.example.sqlite2.Lib;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.sqlite2.Lib.EstructuraTabla.ColumnaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TablaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TipoDatoSqLite;
import com.example.sqlite2.Lib.ReadTable.DatosColumna;
import com.example.sqlite2.Lib.ReadTable.DatosTabla;
import com.example.sqlite2.Lib.ReadTable.Fila;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Model {
    private ConexionSqLite conexionSQLite;
    private Context context;
    private TablaCrear tablaDto;


    private String CrearTabla;
    private String BorrarTabla;
    private String LeerTabla;

    private static List<DatosColumna> datosColumnas;


    public Model(Context contexto, TablaCrear tablaDto1) {
        this.context = contexto;
        this.tablaDto = tablaDto1;

        GeneradorCodigos codigos = new GeneradorCodigos(tablaDto);
        CrearTabla = codigos.getCrearTabla();
        BorrarTabla = codigos.getBorrarTabla();
        LeerTabla = codigos.getLeerTabla();

        conexionSQLite = new ConexionSqLite(context, "bd_" + tablaDto.getNombreTabla(), null, 1,
                CrearTabla, BorrarTabla);
        plantillaDatos();
    }

    private void plantillaDatos(){
        datosColumnas = new ArrayList<>();
        for (Iterator<ColumnaCrear> iterator = tablaDto.getColumnasDtos().iterator(); iterator.hasNext();) {
            ColumnaCrear next = iterator.next();
            datosColumnas.add(new DatosColumna(next.getNombreColumna(), null));
        }
    }

    private ConexionSqLite CrearConexion(){
        ConexionSqLite cSqL = new ConexionSqLite(context, "bd_" + tablaDto.getNombreTabla(), null, 1,
                CrearTabla, BorrarTabla);
        return cSqL;
    }

    private SQLiteDatabase iniciarLecturaDB() {
        conexionSQLite = CrearConexion();
        SQLiteDatabase db = conexionSQLite.getReadableDatabase();
        return db;
    }

    private SQLiteDatabase iniciarEscrituraDB() {
        conexionSQLite = CrearConexion();
        SQLiteDatabase db = conexionSQLite.getWritableDatabase();
        return db;
    }

    public DatosTabla LeerTabla(){
        SQLiteDatabase db = iniciarLecturaDB();
        Cursor cursor = db.rawQuery(LeerTabla, null);
        List<ContentValues> datos = new ArrayList<>();
        for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
            ContentValues valoresColumna = new ContentValues();
            valoresColumna.put("id", cursor.getInt(0));
            int columnaLeida = 1;
            for (Iterator<ColumnaCrear> iterator = tablaDto.getColumnasDtos().iterator(); iterator.hasNext();) {
                ColumnaCrear next = iterator.next();
                switch (next.getTipoDato()){
                    case TipoDatoSqLite.DatoBoolean:{
                        valoresColumna.put(next.getNombreColumna(), cursor.getInt(columnaLeida));
                    }
                    break;
                    case TipoDatoSqLite.DatoEntero:{
                        valoresColumna.put(next.getNombreColumna(), cursor.getInt(columnaLeida));
                    }
                    break;
                    case TipoDatoSqLite.DatoString:{
                        valoresColumna.put(next.getNombreColumna(), cursor.getString(columnaLeida));
                    }
                    break;
                }
                columnaLeida++;
            }
            datos.add(valoresColumna);
        }
        cursor.close();
        db.close();

        DatosTabla datosTabla = new DatosTabla();
        List<Fila> filas = datosTabla.getTablaCompleta();
        for (int i=0; i<datos.size();i++){
            ContentValues values = datos.get(i);
            Fila filaDto = new Fila();
            List<DatosColumna> fila = filaDto.getFila();
            fila.add(new DatosColumna("Id",Integer.toString(i + 1)));
            for (Iterator<ColumnaCrear> iterator = tablaDto.getColumnasDtos().iterator(); iterator.hasNext();) {
                ColumnaCrear next = iterator.next();
                DatosColumna columnaDto = new DatosColumna();
                columnaDto.setNombreColumna(next.getNombreColumna());
                Object o = values.get(next.getNombreColumna());
                switch (next.getTipoDato()){
                    case TipoDatoSqLite.DatoBoolean:{
                        int dato = (int) o;
                        if(dato==1){
                            columnaDto.setDatoColumna(Boolean.toString(true));
                        }else{
                            columnaDto.setDatoColumna(Boolean.toString(false));
                        }
                    }
                    break;
                    case TipoDatoSqLite.DatoEntero:{
                        int dato = (int) o;
                        columnaDto.setDatoColumna(Integer.toString(dato));
                    }
                    break;
                    case TipoDatoSqLite.DatoString:{
                        String dato = (String) o;
                        columnaDto.setDatoColumna(dato);
                    }
                    break;
                }
                fila.add(columnaDto);
            }
            filaDto.setFila(fila);
            filas.add(filaDto);
        }
        datosTabla.setTablaCompleta(filas);
        
        
        return datosTabla;
    }

    public Long InsertarDatos(ContentValues valoresInsertar){
        SQLiteDatabase db = iniciarEscrituraDB();
        Long idInsertado = db.insert(tablaDto.getNombreTabla(), " id ", valoresInsertar);
        db.close();
        if (idInsertado > 0) {
            //Log.e("SQLite", "Datos Guardados");
            return idInsertado;
        }
        //Log.e("SQLite", "Error Guardar datos");
        return new Long(0);
    }

    public int ActualizarDatos(ContentValues values, String idFilaActualizar){
        SQLiteDatabase db = iniciarEscrituraDB();
        int update = db.update(tablaDto.getNombreTabla(), values, " id = " + idFilaActualizar, null);
        db.close();
        if (update > 0) {
            //Log.e("SQLite", "Datos Guardados");
            return update;
        }
        //Log.e("SQLite", "Error Guardar datos");
        return -1;
    }


    public List<DatosColumna> getPlantillaManipulacionDatos() {
        return datosColumnas;
    }

    public int cantidadDatosInsertar(){
        return tablaDto.getColumnasDtos().size();
    }
}
