package com.example.sqlite2.Lib.ReadTable;

import java.util.ArrayList;
import java.util.List;

public class Fila {

    List<DatosColumna> fila;

    public Fila() {
        fila = new ArrayList<>();
    }

    public List<DatosColumna> getFila() {
        return fila;
    }

    public void setFila(List<DatosColumna> fila) {
        this.fila = fila;
    }
}
