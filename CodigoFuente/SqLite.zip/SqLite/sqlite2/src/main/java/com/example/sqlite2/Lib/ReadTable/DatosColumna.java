package com.example.sqlite2.Lib.ReadTable;

public class DatosColumna {
    String nombreColumna;
    String datoColumna;

    public DatosColumna() {
    }

    public DatosColumna(String nombreColumna, String datoColumna) {
        this.nombreColumna = nombreColumna;
        this.datoColumna = datoColumna;
    }

    public String getNombreColumna() {
        return nombreColumna;
    }

    public String getDatoColumna() {
        return datoColumna;
    }

    public void setNombreColumna(String nombreColumna) {
        this.nombreColumna = nombreColumna;
    }

    public void setDatoColumna(String datoColumna) {
        this.datoColumna = datoColumna;
    }
}
