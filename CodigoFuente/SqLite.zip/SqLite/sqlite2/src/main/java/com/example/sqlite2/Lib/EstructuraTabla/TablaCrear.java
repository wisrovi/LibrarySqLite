package com.example.sqlite2.Lib.EstructuraTabla;

import java.util.List;

public class TablaCrear {
    String nombreTabla;
    List<ColumnaCrear> columnasDtos;

    public List<ColumnaCrear> getColumnasDtos() {
        return columnasDtos;
    }

    public void setColumnasDtos(List<ColumnaCrear> columnasDtos) {
        this.columnasDtos = columnasDtos;
    }

    public String getNombreTabla() {
        return nombreTabla;
    }

    public void setNombreTabla(String nombreTabla) {
        this.nombreTabla = nombreTabla;
    }
}
