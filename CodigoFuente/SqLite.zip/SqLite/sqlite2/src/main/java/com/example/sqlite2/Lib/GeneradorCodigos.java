package com.example.sqlite2.Lib;


import com.example.sqlite2.Lib.EstructuraTabla.ColumnaCrear;
import com.example.sqlite2.Lib.EstructuraTabla.TablaCrear;

import java.util.Iterator;
import java.util.List;


public class GeneradorCodigos {

    String CrearTabla = "";
    String BorrarTabla = "";
    String LeerTabla = "";

    public GeneradorCodigos(TablaCrear tablaDto){
        tablaDto.setNombreTabla(tablaDto.getNombreTabla().toLowerCase());

        CrearTabla = "CREATE TABLE " + tablaDto.getNombreTabla() + " ( " + " id " + " INTEGER PRIMARY KEY AUTOINCREMENT , ";
        List<ColumnaCrear> columnas = tablaDto.getColumnasDtos();
        for (Iterator<ColumnaCrear> iterator = columnas.iterator(); iterator.hasNext();) {
            ColumnaCrear next = iterator.next();
            CrearTabla = CrearTabla + next.getNombreColumna().toLowerCase() + next.getTipoDato() + ", ";

        }
        CrearTabla = CrearTabla.substring(0, CrearTabla.length()-2) + " )";

        BorrarTabla = "DROP TABLE IF EXISTS " + tablaDto.getNombreTabla();

        LeerTabla = "SELECT * FROM " + tablaDto.getNombreTabla();

    }

    public String getBorrarTabla() {
        return BorrarTabla;
    }

    public String getCrearTabla() {
        return CrearTabla;
    }

    public String getLeerTabla() {
        return LeerTabla;
    }

}
