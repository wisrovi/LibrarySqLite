package com.example.sqlite2.Lib.EstructuraTabla;

public class ColumnaCrear {
    String NombreColumna;
    String TipoDato;

    public ColumnaCrear(String col, String tipo){
        this.NombreColumna = col;
        this.TipoDato = tipo;
    }

    public String getTipoDato() {
        return TipoDato;
    }

    public String getNombreColumna() {
        return NombreColumna;
    }
}
