package com.example.sqlite2.Lib.EstructuraTabla;

public class TipoDatoSqLite {
    public static final String DatoEntero = " INTEGER ";
    public static final String DatoString = " TEXT ";
    public static final String DatoBoolean = " BIT ";
}
