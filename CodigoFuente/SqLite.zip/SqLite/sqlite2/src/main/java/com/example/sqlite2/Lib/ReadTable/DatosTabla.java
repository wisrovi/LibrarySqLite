package com.example.sqlite2.Lib.ReadTable;

import java.util.ArrayList;
import java.util.List;

public class DatosTabla {
    List<Fila> tablaCompleta;

    public DatosTabla() {
        tablaCompleta = new ArrayList<>();
    }

    public List<Fila> getTablaCompleta() {
        return tablaCompleta;
    }

    public void setTablaCompleta(List<Fila> tablaCompleta) {
        this.tablaCompleta = tablaCompleta;
    }
}
