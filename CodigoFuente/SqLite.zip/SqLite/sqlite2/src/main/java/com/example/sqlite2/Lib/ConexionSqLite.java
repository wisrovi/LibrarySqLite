package com.example.sqlite2.Lib;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ConexionSqLite extends SQLiteOpenHelper {


    private String CrearTabla;
    private String BorrarTabla;


    public ConexionSqLite(Context context, String name, SQLiteDatabase.CursorFactory factory, int version,
                          String crearTabla1, String BorrarTabla1) {
        super(context, name, factory, version);
        this.BorrarTabla = BorrarTabla1;
        this.CrearTabla = crearTabla1;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CrearTabla);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(BorrarTabla);
    }
}
