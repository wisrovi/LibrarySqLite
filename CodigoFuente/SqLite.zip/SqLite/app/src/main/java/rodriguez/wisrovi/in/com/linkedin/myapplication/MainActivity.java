package rodriguez.wisrovi.in.com.linkedin.myapplication;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;




public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*TablaCrear tabla = new TablaCrear();
        tabla.setNombreTabla("WILI");
        List<ColumnaCrear> columnasDtos = new ArrayList<>();
        columnasDtos.add(new ColumnaCrear("nombre", TipoDatoSqLite.DatoString));
        columnasDtos.add(new ColumnaCrear("documento", TipoDatoSqLite.DatoEntero));
        columnasDtos.add(new ColumnaCrear("habilitado", TipoDatoSqLite.DatoBoolean));
        tabla.setColumnasDtos(columnasDtos);

        ConectarSqLite conectarSqLite = new ConectarSqLite(getApplicationContext(), tabla);

        List<DatosColumna> datosColumnas = conectarSqLite.plantillaUsoDatos();
        datosColumnas.get(0).setDatoColumna("William");
        datosColumnas.get(1).setDatoColumna(Integer.toString(123456));
        datosColumnas.get(2).setDatoColumna(Boolean.toString(false));

        List<DatosColumna> newdatosColumnas = conectarSqLite.plantillaUsoDatos();
        newdatosColumnas.get(0).setDatoColumna("Steve");


        int aLong = conectarSqLite.InsertarDatos(datosColumnas);
        switch (aLong) {
            case 0: {
                //no se pudo insertar
            }
            break;
            case -1: {
                //"Datos incompletos para ser guardados"
            }
            break;
            case -2: {
                //error procesar datos
            }
            break;
        }


        int i = conectarSqLite.ActualizarDatos(newdatosColumnas, 16);


        DatosTabla datos = conectarSqLite.LeerTabla();
        for (int indiceFilas = 0; indiceFilas < datos.getTablaCompleta().size(); indiceFilas++) {
            Fila fila = datos.getTablaCompleta().get(indiceFilas);
            for (int indiceColumna = 0; indiceColumna < fila.getFila().size(); indiceColumna++) {
                DatosColumna columnas = fila.getFila().get(indiceColumna);
                Log.e(columnas.getNombreColumna(), columnas.getDatoColumna());
            }
        }*/

        Log.e("Tabla", "Tabla leida");
    }


}
